import java.util.*;
import javafx.util.Pair;

public class Graph
{
    private ArrayList<Vertex> Vertices = new ArrayList<>();

    public Vertex addvertex(String id)
    {
        Vertex newvertex = new Vertex(id);
        Vertices.add(newvertex);
        return newvertex;
    }

    public void addvertex(Vertex v)
    {
        Vertices.add(v);
    }

    public Vertex getvertex(String s)
    {
        for(Vertex v : Vertices )
        {
            if (v.Name==s)
            {
                return v;
            }
        }
        return null;
    }

    public void newEdgeForSmallGraph(Vertex from, Vertex to, int dist, int time)
    {
        Edge newEdge=new Edge(from,to);
        newEdge.distance = dist;
        newEdge.time = time;
    }

    public void newEdgeForBigGraph(Vertex from, Vertex to, int dist)
    {
        Edge newEdge=new Edge(from,to);
        newEdge.distance = dist;
    }

    public Pair<Integer, Map<Vertex,Vertex> > ShortestDistance(Vertex start, Vertex end)
    {
        Map<Vertex,Vertex> PredecessorMapForDist = new HashMap<>();
        Map<Vertex,Integer> DistanceMap = new HashMap<>();
        Map<Vertex, Integer> TMap = new HashMap<>();

        // initialize arrays

        for(Vertex v: Vertices)
        {
            DistanceMap.put(v,1000);                //1000 = simulation of infinity
            TMap.put(v,1000);
            PredecessorMapForDist.put(v, null);
        }

        DistanceMap.put(start, 0);                  //Edges     - De skal opdateres sammen hver gang
        TMap.put(start, 0);                         //Vertices  - De skal opdateres sammen hver gang

        for (int i = 0; i < Vertices.size() ; i++)
        {
            Vertex current = getMin(TMap);


            for (int j = 0; j < current.getOutEdges().size(); j++)
            {
                // Hvis min current er større end current + den nye edge.
                //Dette er for distance
                if (DistanceMap.get(current) + current.getOutEdges().get(j).distance < DistanceMap.get(current.getOutEdges().get(j).getTovertex()))
                {
                    DistanceMap.put(current.getOutEdges().get(j).getTovertex(), DistanceMap.get(current) + current.getOutEdges().get(j).distance);
                    TMap.put(current.getOutEdges().get(j).getTovertex(), DistanceMap.get(current) + current.getOutEdges().get(j).distance);
                    PredecessorMapForDist.put(current.getOutEdges().get(j).getTovertex(),current);
                }
            }

            TMap.remove(current);
        }


        //implement Dijkstra - se den anden kode, vi allerede har lavet.

        return (new Pair<Integer,Map<Vertex,Vertex>> (DistanceMap.get(end), PredecessorMapForDist));
    }

    public Pair<Integer, Map<Vertex,Vertex> > ShortestTime(Vertex start, Vertex end)
    {
        Map<Vertex,Vertex> PredecessorMapForTime = new HashMap<>();
        Map<Vertex,Integer> TimeMap = new HashMap<>();
        Map<Vertex, Integer> TMap = new HashMap<>();

        for(Vertex v: Vertices)
        {
            TimeMap.put(v,1000);                //1000 = simulation of infinity
            TMap.put(v,1000);
            PredecessorMapForTime.put(v, null);
        }

        TimeMap.put(start, 0);                  //Edges     - De skal opdateres sammen hver gang
        TMap.put(start, 0);                         //Vertices  - De skal opdateres sammen hver gang

        for (int i = 0; i < Vertices.size() ; i++)
        {
            Vertex current = getMin(TMap);

            for (int j = 0; j < current.getOutEdges().size(); j++)
            {
               //Dette er for time!
               if (TimeMap.get(current) + current.getOutEdges().get(j).time < TimeMap.get(current.getOutEdges().get(j).getTovertex()))

                {
                    TimeMap.put(current.getOutEdges().get(j).getTovertex(), TimeMap.get(current) + current.getOutEdges().get(j).time);
                    TMap.put(current.getOutEdges().get(j).getTovertex(), TimeMap.get(current) + current.getOutEdges().get(j).time);
                    PredecessorMapForTime.put(current.getOutEdges().get(j).getTovertex(),current);
                }
            }

            TMap.remove(current);
        }


        //implement Dijkstra - se den anden kode, vi allerede har lavet.

        return (new Pair<Integer,Map<Vertex,Vertex>> (TimeMap.get(end), PredecessorMapForTime));
    }


    public Vertex getMin(Map<Vertex,Integer> minTMap)
    {
        Map.Entry<Vertex, Integer> minVertex = null;
        for (Map.Entry<Vertex,Integer> entry : minTMap.entrySet())
        {
            if (minVertex == null || minVertex.getValue()>entry.getValue())
            {
                minVertex = entry;
            }
        }

        return minVertex.getKey(); //Returnere den Vertex, for hvilke tal/Integer der er mindst
    }
}



//Denne klasse må IKKE ændres!
class Vertex
{
    String Name;
    ArrayList<Edge> OutEdges = new ArrayList<>();

    public  Vertex(String id)
    {
        Name=id;
    }

    public void addOutEdge(Edge outedge)
    {
        OutEdges.add(outedge);

    }

    public ArrayList<Edge> getOutEdges()
    {
        return OutEdges;
    }
}

//Denne klasse på IKKE ændres!
class Edge{
    private Vertex fromvertex;
    private Vertex tovertex;
    public int distance=0;
    public int time=0;

    public Vertex getTovertex() {
        return tovertex;
    }

    public Edge(Vertex from, Vertex to){
        fromvertex=from;
        tovertex=to;
        fromvertex.addOutEdge(this);
        //If not directional
        tovertex.addOutEdge(this);
    }
}

