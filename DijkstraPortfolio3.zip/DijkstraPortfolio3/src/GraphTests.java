import javafx.util.Pair;
import java.util.ArrayList;
import java.util.Map;

public class GraphTests
{
    public static void main(String[] args)
    {
        // Create graph
        GraphTests TestGraph = new GraphTests();

        Graph g = TestGraph.MakeSmallGraph();
        Graph newGraph = TestGraph.MakeBigGraph();

        Vertex start = g.getvertex("A");
        Vertex end = g.getvertex("F");

        Vertex newStart = newGraph.getvertex("10");
        Vertex newEnd = newGraph.getvertex("6");

        Pair<Integer, Map<Vertex, Vertex>> resultsForTime = g.ShortestTime(start, end);
        Pair<Integer, Map<Vertex, Vertex>> resultsForDist = g.ShortestDistance(start, end);
        Pair<Integer, Map<Vertex, Vertex>> resultsForNewDist = newGraph.ShortestDistance(newStart, newEnd);

        Vertex currentDist = end;
        Vertex currentTime = end;
        Vertex newCurrentDist = newEnd;

        ArrayList<Vertex> PathDist = new ArrayList<>();
        PathDist.add(end);

        ArrayList<Vertex> PathTime = new ArrayList<>();
        PathTime.add(end);

        ArrayList<Vertex> newPathDist = new ArrayList<>();
        newPathDist.add(newEnd);

        System.out.println("This is the shortest path for distance: ");
        while ((currentDist != start) && (resultsForDist.getValue().get(currentDist) != null))
        {
            currentDist = resultsForDist.getValue().get(currentDist);
            PathDist.add(0, currentDist);
        }

        for (Vertex v : PathDist)
        {
            System.out.print(v.Name);
            if (v != end)
            {
                System.out.print("->");
            }
        }

        System.out.println("");
        System.out.println("");
        System.out.println("This is the shortest path for time: ");
        while((currentTime != start) && (resultsForTime.getValue().get(currentTime) != null))
        {
            currentTime = resultsForTime.getValue().get(currentTime);
            PathTime.add(0, currentTime);
        }

        for (Vertex v : PathTime)
        {
            System.out.print(v.Name);
            if (v != end)
            {
                System.out.print("->");
            }
        }
        System.out.println();
        System.out.println();

        System.out.println("This is our new END! ");
        while ((newCurrentDist != newStart) && (resultsForNewDist.getValue().get(newCurrentDist) != null))
        {
            newCurrentDist = resultsForNewDist.getValue().get(newCurrentDist);
            newPathDist.add(0, newCurrentDist);
        }

        for (Vertex v : newPathDist)
        {
            System.out.print(v.Name);
            if (v != newEnd)
            {
                System.out.print("->");
            }
        }

    }


    public Graph MakeSmallGraph()
    {
        Graph myGraph = new Graph();

        final Vertex A = myGraph.addvertex("A");
        final Vertex B = myGraph.addvertex("B");
        final Vertex C = myGraph.addvertex("C");
        final Vertex D = myGraph.addvertex("D");
        final Vertex E = myGraph.addvertex("E");
        final Vertex F = myGraph.addvertex("F");

        myGraph.newEdgeForSmallGraph(A, B, 1, 2);
        myGraph.newEdgeForSmallGraph(A, C, 5, 1);
        myGraph.newEdgeForSmallGraph(A, D, 4, 6);
        myGraph.newEdgeForSmallGraph(B, C, 3, 2);
        myGraph.newEdgeForSmallGraph(B, D, 2, 3);
        myGraph.newEdgeForSmallGraph(B, E, 2, 4);
        myGraph.newEdgeForSmallGraph(C, F, 1, 8);
        myGraph.newEdgeForSmallGraph(C, E, 2, 2);
        myGraph.newEdgeForSmallGraph(D, F, 2, 7);
        myGraph.newEdgeForSmallGraph(E, F, 3, 6);

        return myGraph;
    }

    public Graph MakeBigGraph()
    {
        Graph bigGraph = new Graph();

        final Vertex v1 =   bigGraph.addvertex("1");
        final Vertex v2 =   bigGraph.addvertex("2");
        final Vertex v3 =   bigGraph.addvertex("3");
        final Vertex v4 =   bigGraph.addvertex("4");
        final Vertex v5 =   bigGraph.addvertex("5");
        final Vertex v6 =   bigGraph.addvertex("6");
        final Vertex v7 =   bigGraph.addvertex("7");
        final Vertex v8 =   bigGraph.addvertex("8");
        final Vertex v9 =   bigGraph.addvertex("9");
        final Vertex v10 =  bigGraph.addvertex("10");

        bigGraph.newEdgeForBigGraph(v1, v2, 10);
        bigGraph.newEdgeForBigGraph(v1, v4, 20);
        bigGraph.newEdgeForBigGraph(v1, v5, 20);
        bigGraph.newEdgeForBigGraph(v1, v6, 5);
        bigGraph.newEdgeForBigGraph(v1, v7, 15);

        bigGraph.newEdgeForBigGraph(v2, v3, 5);
        bigGraph.newEdgeForBigGraph(v2, v4, 10);

        bigGraph.newEdgeForBigGraph(v3, v2, 15);
        bigGraph.newEdgeForBigGraph(v3, v4, 5);

        bigGraph.newEdgeForBigGraph(v4, v5, 10);

        bigGraph.newEdgeForBigGraph(v5, v6, 5);

        bigGraph.newEdgeForBigGraph(v7, v6, 10);

        bigGraph.newEdgeForBigGraph(v8, v1, 5);
        bigGraph.newEdgeForBigGraph(v8, v2, 20);
        bigGraph.newEdgeForBigGraph(v8, v7, 5);

        bigGraph.newEdgeForBigGraph(v9, v2, 15);
        bigGraph.newEdgeForBigGraph(v9, v8, 20);
        bigGraph.newEdgeForBigGraph(v9, v10, 10);

        bigGraph.newEdgeForBigGraph(v10, v2, 5);
        bigGraph.newEdgeForBigGraph(v10, v3, 15);


     return bigGraph;
    }

}


